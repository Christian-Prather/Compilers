#!/bin/bash

cmake .
make -j4