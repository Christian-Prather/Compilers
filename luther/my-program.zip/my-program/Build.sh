#!/bin/bash

cmake .
make -j2